const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path');
const dotenv = require('dotenv');
const session = require('express-session');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static('public')); // Serve static files from the 'public' directory
app.use('/faculty-Admin', express.static(path.join(__dirname, 'faculty-Admin')));
app.use('/lab-Admin', express.static(path.join(__dirname, 'lab-Admin')));
app.use('/student-page', express.static(path.join(__dirname, 'student-page')));

// Session Management
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Set to true if using HTTPS
}));

// MySQL Connection
const db = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root', // Default XAMPP username
    password: process.env.DB_PASSWORD || '', // Default XAMPP password
    database: process.env.DB_NAME || 'lab_management'
});

db.connect(err => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to MySQL Database');
});

// Serve home.html on the root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'home.html')); // Adjust path if necessary
});

// Serve login.html on the /login route
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html')); // Adjust path if necessary
});

// Serve lab.html
app.get('/lab-Admin/pages/lab.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'lab-Admin', 'pages', 'lab.html'));
});

// Serve equipments.html
app.get('/lab-Admin/pages/equipments.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'lab-Admin', 'pages', 'equipments.html'));
});

// Serve reports.html
app.get('/lab-Admin/pages/reports.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'lab-Admin', 'pages', 'reports.html'));
});

// Serve issues.html
app.get('/student-page/pages/issues.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'student-page', 'pages', 'issues.html'));
});

// Serve faculty reports page
app.get('/faculty-Admin/facultyPages/reports.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'faculty-Admin', 'facultyPages', 'reports.html'));
});

// Serve attendance.html
app.get('/lab-Admin/pages/attendance.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'lab-Admin', 'pages', 'attendance.html'));
});

// Login Endpoint
app.post('/login', (req, res) => {
    const { username, password, role } = req.body;

    const tableMap = {
        'faculty': 'faculty_admins',
        'lab': 'lab_admins',
        'student': 'students'
    };

    const query = `SELECT * FROM ${tableMap[role]} WHERE username = ? AND password = ?`;
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error executing query:', err);
            return res.status(500).json({ success: false, message: 'Internal server error.' });
        }

        if (results.length > 0) {
            req.session.userId = results[0].id; // Store user ID in session
            req.session.role = role; // Store user role in session
            let redirectPage;
            switch (role) {
                case 'faculty':
                    redirectPage = '/faculty-Admin/facultyPages/faculty.html';
                    break;
                case 'lab':
                    redirectPage = '/lab-Admin/pages/lab.html';
                    break;
                case 'student':
                    redirectPage = '/student-page/pages/student.html';
                    break;
            }

            res.status(200).json({ success: true, message: 'Login successful!', redirect: redirectPage });
        } else {
            res.status(401).json({ success: false, message: 'Invalid username or password.' });
        }
    });
});

// Fetch Student Data Endpoint
app.get('/api/student/profile', (req, res) => {
    const userId = req.session.userId; // Get user ID from session
    const role = req.session.role; // Get user role from session

    if (!userId || role !== 'student') {
        return res.status(401).json({ message: 'Unauthorized access.' });
    }

    const query = `SELECT name, student_id, section, academic_year FROM students WHERE id = ?`;
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching student data:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'Student not found.' });
        }

        res.status(200).json(results[0]);
    });
});

// Fetch Specific Student Endpoint
app.get('/student/:id', (req, res) => {
    const studentId = req.params.id;
    const query = `SELECT student_id, name, age, section, academic_year FROM students WHERE id = ?`;
    db.query(query, [studentId], (err, results) => {
        if (err) {
            console.error('Error fetching student data:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'Student not found.' });
        }

        res.status(200).json(results[0]);
    });
});

// Logout Endpoint
app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error('Error destroying session:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.redirect('/login');
    });
});

// Register Student Endpoint
app.post('/register-student', (req, res) => {
    const { faculty_username, faculty_password, username, student_id, name, age, section, academic_year, password } = req.body;

    console.log('Received registration request:', req.body); // Log the received data

    const facultyQuery = `SELECT * FROM faculty_admins WHERE username = ? AND password = ?`;
    db.query(facultyQuery, [faculty_username, faculty_password], (err, facultyResults) => {
        if (err) {
            console.error('Error checking faculty credentials:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }

        if (facultyResults.length === 0) {
            return res.status(401).json({ message: 'Unauthorized. Only faculty can register students.' });
        }

        const studentQuery = `INSERT INTO students (username, student_id, name, age, section, academic_year, password) VALUES (?, ?, ?, ?, ?, ?, ?)`;
        db.query(studentQuery, [username, student_id, name, age, section, academic_year, password], (err, results) => {
            if (err) {
                console.error('Error registering student:', err);
                return res.status(500).json({ message: 'Failed to register student.' });
            }
            res.status(201).json({ message: 'Student registered successfully!' });
        });
    });
});

// Fetch Students Endpoint
app.get('/students', (req, res) => {
    const query = `SELECT id, student_id, name, age, section, academic_year FROM students`;
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching students:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(200).json(results);
    });
});

// Delete Student Endpoint
app.delete('/students/:id', (req, res) => {
    const id = req.params.id;
    const query = `DELETE FROM students WHERE id = ?`;
    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error deleting student:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(200).json({ message: 'Student deleted successfully!' });
    });
});

// Serve Student Profile Page
app.get('/student-profile', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'student_template.html'));
});

// Add Equipment Endpoint
app.post('/add-equipment', (req, res) => {
    const { name, location, category, quantity } = req.body;

    const query = `INSERT INTO equipment (name, location, category, quantity) VALUES (?, ?, ?, ?)`;
    db.query(query, [name, location, category, quantity], (err, results) => {
        if (err) {
            console.error('Error adding equipment:', err);
            return res.status(500).json({ success: false, message: 'Internal server error.' });
        }
        res.status(200).json({ success: true, message: 'Equipment added successfully!' });
    });
});

// Fetch Equipment Inventory Endpoint
app.get('/equipment', (req, res) => {
    const query = `SELECT id, name, location, category, quantity FROM equipment`;
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching equipment inventory:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(200).json(results);
    });
});

// Fetch Specific Equipment Endpoint
app.get('/equipment/:id', (req, res) => {
    const equipmentId = req.params.id;
    const query = `SELECT id, name, location, category, quantity FROM equipment WHERE id = ?`;
    db.query(query, [equipmentId], (err, results) => {
        if (err) {
            console.error('Error fetching equipment data:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'Equipment not found.' });
        }

        res.status(200).json(results[0]);
    });
});

// Delete Equipment Endpoint
app.delete('/equipment/:id', (req, res) => {
    const id = req.params.id;
    const query = `DELETE FROM equipment WHERE id = ?`;
    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error deleting equipment:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(200).json({ message: 'Equipment deleted successfully!' });
    });
});

// Fetch Schedule Endpoint
app.get('/api/schedule', (req, res) => {
    const query = `
        SELECT id, course_name, instructor_name, lab_name, location, date, time_slot
        FROM schedule
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching schedule:', err);
            return res.status(500).json({ success: false, message: 'Internal server error.' });
        }
        console.log('Fetched schedule data:', results); // Log the fetched data
        res.status(200).json({ success: true, data: results });
    });
});

// Book Lab Session Endpoint
app.post('/book-lab', (req, res) => {
    const { course_name, instructor_name, lab_name, location, date, time_slot } = req.body;

    console.log('Received booking request:', req.body); // Log the received data

    // Basic validation
    if (!course_name || !instructor_name || !lab_name || !location || !date || !time_slot) {
        return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    // Check for scheduling conflicts (example logic)
    const conflictQuery = `
        SELECT * FROM schedule
        WHERE lab_name = ? AND date = ? AND time_slot = ?
    `;

    db.query(conflictQuery, [lab_name, date, time_slot], (err, results) => {
        if (err) {
            console.error('Error checking for conflicts:', err);
            return res.status(500).json({ success: false, message: 'Internal server error.' });
        }

        if (results.length > 0) {
            return res.status(409).json({ success: false, message: 'Conflict: Lab is already booked for this time.' });
        }

        const insertQuery = `
            INSERT INTO schedule (course_name, instructor_name, lab_name, location, date, time_slot)
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        db.query(insertQuery, [course_name, instructor_name, lab_name, location, date, time_slot], (err, results) => {
            if (err) {
                console.error('Error booking lab session:', err);
                return res.status(500).json({ success: false, message: 'Internal server error.' });
            }
            const newId = results.insertId; // Get the ID of the newly inserted record
            res.status(200).json({ success: true, message: 'Lab session booked successfully!', id: newId });
        });
    });
});

// Edit Lab Session Endpoint
app.put('/schedule/:id', (req, res) => {
    const { course_name, instructor_name, lab_name, location, date, time_slot } = req.body;
    const id = req.params.id;

    console.log('Received update request:', req.body); // Log the received data

    // Basic validation
    if (!course_name || !instructor_name || !lab_name || !location || !date || !time_slot) {
        return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    // Check for scheduling conflicts (example logic)
    const conflictQuery = `
        SELECT * FROM schedule
        WHERE lab_name = ? AND date = ? AND time_slot = ? AND id != ?
    `;

    db.query(conflictQuery, [lab_name, date, time_slot, id], (err, results) => {
        if (err) {
            console.error('Error checking for conflicts:', err);
            return res.status(500).json({ success: false, message: 'Internal server error.' });
        }

        if (results.length > 0) {
            return res.status(409).json({ success: false, message: 'Conflict: Lab is already booked for this time.' });
        }

        const updateQuery = `
            UPDATE schedule
            SET course_name = ?, instructor_name = ?, lab_name = ?, location = ?, date = ?, time_slot = ?
            WHERE id = ?
        `;

        db.query(updateQuery, [course_name, instructor_name, lab_name, location, date, time_slot, id], (err, results) => {
            if (err) {
                console.error('Error updating lab session:', err);
                return res.status(500).json({ success: false, message: 'Internal server error.' });
            }
            res.status(200).json({ success: true, message: 'Lab session updated successfully!' });
        });
    });
});

// Delete Lab Session Endpoint
app.delete('/schedule/:id', (req, res) => {
    const id = req.params.id;
    const query = `DELETE FROM schedule WHERE id = ?`;
    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error deleting lab session:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(200).json({ message: 'Lab session deleted successfully!' });
    });
});

// Fetch Admin Name Endpoint
app.get('/api/admin/name', (req, res) => {
    const userId = req.session.userId; // Get user ID from session
    const role = req.session.role; // Get user role from session

    if (!userId || role !== 'lab') {
        return res.status(401).json({ message: 'Unauthorized access.' });
    }

    const query = `SELECT name FROM lab_admins WHERE id = ?`;
    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching admin name:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: 'Admin not found.' });
        }

        res.status(200).json(results[0]);
    });
});

// Submit Report Endpoint
app.post('/submit-report', (req, res) => {
    const { reported_by, reporter_name, issue_type, urgency, description, location } = req.body;

    const query = `INSERT INTO issues (reported_by, reporter_name, issue_type, urgency, description, location) VALUES (?, ?, ?, ?, ?, ?)`;
    db.query(query, [reported_by, reporter_name, issue_type, urgency, description, location], (err, results) => {
        if (err) {
            console.error('Error submitting report:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(201).json({ message: 'Report submitted successfully!' });
    });
});

// Fetch Reports Endpoint
app.get('/reports', (req, res) => {
    const query = `SELECT * FROM issues`;
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching reports:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(200).json(results);
    });
});

// Fetch Filtered Reports Endpoint
app.get('/reports/filter', (req, res) => {
    const { location, status, date } = req.query;
    let query = `SELECT * FROM issues WHERE 1=1`;
    const values = [];

    if (location) {
        query += ` AND location = ?`;
        values.push(location);
    }
    if (status) {
        query += ` AND status = ?`;
        values.push(status);
    }
    if (date) {
        query += ` AND DATE(reported_at) = ?`;
        values.push(date);
    }

    db.query(query, values, (err, results) => {
        if (err) {
            console.error('Error fetching filtered reports:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(200).json(results);
    });
});

// Update Report Status Endpoint
app.put('/reports/:id/status', (req, res) => {
    const id = req.params.id;
    const { status, feedback } = req.body;

    const query = `UPDATE issues SET status = ?, feedback = ? WHERE id = ?`;
    db.query(query, [status, feedback, id], (err, results) => {
        if (err) {
            console.error('Error updating report status:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(200).json({ message: 'Report status updated successfully!' });
    });
});

// Mark Attendance Endpoint
app.post('/mark-attendance', (req, res) => {
    const { student_id, name, time } = req.body;

    const query = `INSERT INTO attendance (student_id, name, time) VALUES (?, ?, ?)`;
    db.query(query, [student_id, name, time], (err, results) => {
        if (err) {
            console.error('Error marking attendance:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(201).json({ message: 'Attendance marked successfully!' });
    });
});

// Fetch Attendance Log Endpoint
app.get('/attendance-log', (req, res) => {
    const query = `SELECT * FROM attendance`;
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching attendance log:', err);
            return res.status(500).json({ message: 'Internal server error.' });
        }
        res.status(200).json(results);
    });
});

// Start server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
